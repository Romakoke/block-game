@echo off
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" (
  echo Microsoft Edge was not found.
  pause
  exit /b 1
)
echo Fullscreen kiosk DEMO only. Windows itself is NOT locked.
echo Press Ctrl+Alt+Delete to switch Windows sessions if needed.
start "" "%EDGE%" --kiosk "https://damoo.kz/#/home" --edge-kiosk-type=fullscreen --no-first-run

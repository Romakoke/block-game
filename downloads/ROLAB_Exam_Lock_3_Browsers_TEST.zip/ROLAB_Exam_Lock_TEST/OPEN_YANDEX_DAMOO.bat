@echo off
set "BROWSER=%LocalAppData%\Yandex\YandexBrowser\Application\browser.exe"
if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\Yandex\YandexBrowser\Application\browser.exe"
if not exist "%BROWSER%" set "BROWSER=%ProgramFiles%\Yandex\YandexBrowser\Application\browser.exe"
if not exist "%BROWSER%" (
  echo Yandex Browser was not found in common installation directories.
  echo You can open https://damoo.kz/#/home in Yandex Browser manually.
  pause
  exit /b 1
)
start "" "%BROWSER%" "https://damoo.kz/#/home"

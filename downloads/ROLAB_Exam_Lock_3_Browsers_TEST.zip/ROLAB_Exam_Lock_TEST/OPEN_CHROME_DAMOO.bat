@echo off
set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%BROWSER%" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%BROWSER%" set "BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not exist "%BROWSER%" (
  echo Google Chrome was not found in common installation directories.
  pause
  exit /b 1
)
start "" "%BROWSER%" "https://damoo.kz/#/home"

$stateRoot = Join-Path $env:ProgramData 'ROLAB\ExamLock'
$manifestPath = Join-Path $stateRoot 'active-state.json'
if (Test-Path -LiteralPath $manifestPath) {
    Write-Host 'ROLAB Exam Lock manifest: ACTIVE' -ForegroundColor Green
} else {
    Write-Host 'ROLAB Exam Lock manifest: NOT ACTIVE' -ForegroundColor Yellow
}
$roots = @(
    'HKLM:\SOFTWARE\Policies\Google\Chrome',
    'HKLM:\SOFTWARE\Policies\Microsoft\Edge',
    'HKLM:\SOFTWARE\Policies\YandexBrowser'
)
foreach ($root in $roots) {
    Write-Host "`n$root" -ForegroundColor Cyan
    foreach ($policy in @('URLBlocklist', 'URLAllowlist', 'ExtensionInstallBlocklist')) {
        $path = "$root\$policy"
        if (Test-Path -LiteralPath $path) {
            $key = Get-Item -LiteralPath $path
            $values = foreach ($name in ($key.GetValueNames() | Sort-Object)) { "${name}: $($key.GetValue($name))" }
            Write-Host ('  ' + $policy + ' => ' + ($values -join ', '))
        } else { Write-Host ('  ' + $policy + ' => not configured') }
    }
}
Write-Host "`nBrowser verification: chrome://policy  edge://policy  browser://policy"

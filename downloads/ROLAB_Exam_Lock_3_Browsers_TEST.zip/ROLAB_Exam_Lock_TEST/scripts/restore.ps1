# Restores only the policy entries this pilot overwrote.
$ErrorActionPreference = 'Stop'
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($id)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run RESTORE_PREVIOUS_SETTINGS.bat as administrator.'
}
$stateRoot = Join-Path $env:ProgramData 'ROLAB\ExamLock'
$manifestPath = Join-Path $stateRoot 'active-state.json'
if (-not (Test-Path -LiteralPath $manifestPath)) {
    Write-Host 'No active ROLAB Exam Lock backup was found. No changes made.' -ForegroundColor Yellow
    exit 0
}
$state = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($state.Version -ne 1) { throw 'Unsupported recovery manifest version.' }
# Validate all files before modifying a single registry key.
foreach ($entry in $state.Entries) {
    if ($entry.Existed) {
        $needed = Join-Path ([string]$state.BackupDirectory) ([string]$entry.BackupFile)
        if (-not (Test-Path -LiteralPath $needed)) { throw "Missing backup: $needed" }
    }
}
foreach ($entry in $state.Entries) {
    $key = [string]$entry.RegistryKey
    if ($key -notmatch '^HKLM\\SOFTWARE\\Policies\\(Google\\Chrome|Microsoft\\Edge|YandexBrowser)\\(URLBlocklist|URLAllowlist|ExtensionInstallBlocklist)$') {
        throw "Unexpected registry path in manifest: $key"
    }
    $path = $key -replace '^HKLM\\', 'Registry::HKEY_LOCAL_MACHINE\'
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
    if ($entry.Existed) {
        $backup = Join-Path ([string]$state.BackupDirectory) ([string]$entry.BackupFile)
        if (-not (Test-Path -LiteralPath $backup)) { throw "Missing backup: $backup" }
        & reg.exe import $backup | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "Could not restore $key" }
    }
}
$yandexPath = 'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\YandexBrowser'
$aliceName = 'YandexAliceMsgDisable'
if ($state.YandexAlice.Existed) {
    if (-not (Test-Path -LiteralPath $yandexPath)) { New-Item -Path $yandexPath -Force | Out-Null }
    New-ItemProperty -LiteralPath $yandexPath -Name $aliceName -PropertyType ([string]$state.YandexAlice.Kind) -Value $state.YandexAlice.Value -Force | Out-Null
} elseif (Test-Path -LiteralPath $yandexPath) {
    Remove-ItemProperty -LiteralPath $yandexPath -Name $aliceName -ErrorAction SilentlyContinue
}
Remove-Item -LiteralPath $manifestPath -Force
Write-Host 'Previous browser policy settings restored.' -ForegroundColor Green
Write-Host ('Original backups retained at: ' + $state.BackupDirectory)
Write-Host 'Restart all browsers and check their policy pages.'

# ROLAB Exam Lock - pilot configuration for Windows 10/11
# Use only on school-managed Windows PCs with an administrator account.
# Requires Windows PowerShell 5.1 and an elevated process.
$ErrorActionPreference = 'Stop'

function Assert-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($id)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run INSTALL_EXAM_LOCK.bat as administrator.'
    }
}

Assert-Admin
$StateRoot = Join-Path $env:ProgramData 'ROLAB\ExamLock'
$ManifestPath = Join-Path $StateRoot 'active-state.json'
if (Test-Path -LiteralPath $ManifestPath) {
    throw 'Exam Lock is already active. Run RESTORE_PREVIOUS_SETTINGS.bat before installing again.'
}

$allowFile = Join-Path (Split-Path -Parent $PSScriptRoot) 'allowed-domains.txt'
if (-not (Test-Path -LiteralPath $allowFile)) { throw 'allowed-domains.txt not found.' }
$allowed = @(Get-Content -LiteralPath $allowFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
if ($allowed.Count -eq 0 -or $allowed.Count -gt 50) { throw 'Allowed domain list must have 1 to 50 entries.' }
foreach ($domain in $allowed) {
    if ($domain -notmatch '^(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$') {
        throw "Invalid domain in allowed-domains.txt: $domain"
    }
}
if ($allowed -notcontains 'damoo.kz') { throw 'damoo.kz must remain in the allowed list for this pilot.' }

$browserRoots = @(
    'HKLM\SOFTWARE\Policies\Google\Chrome',
    'HKLM\SOFTWARE\Policies\Microsoft\Edge',
    'HKLM\SOFTWARE\Policies\YandexBrowser'
)
$names = @('URLBlocklist', 'URLAllowlist', 'ExtensionInstallBlocklist')

New-Item -ItemType Directory -Path $StateRoot -Force | Out-Null
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $StateRoot ('backups_' + $timestamp)
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

$entries = @()
$index = 0
foreach ($root in $browserRoots) {
    foreach ($name in $names) {
        $index++
        $regKey = "$root\$name"
        $psPath = $regKey -replace '^HKLM\\', 'Registry::HKEY_LOCAL_MACHINE\'
        $existed = Test-Path -LiteralPath $psPath
        $regFile = $null
        if ($existed) {
            $regFile = ('original_{0:D2}.reg' -f $index)
            $dest = Join-Path $backupDir $regFile
            & reg.exe export $regKey $dest /y | Out-Null
            if ($LASTEXITCODE -ne 0) { throw "Backup failed: $regKey" }
        }
        $entries += [pscustomobject]@{
            RegistryKey = $regKey
            Existed = [bool]$existed
            BackupFile = $regFile
        }
    }
}

$yandexRoot = 'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\YandexBrowser'
$aliceName = 'YandexAliceMsgDisable'
$aliceExisted = $false
$aliceValue = $null
$aliceKind = $null
if (Test-Path -LiteralPath $yandexRoot) {
    $key = Get-Item -LiteralPath $yandexRoot
    if ($key.GetValueNames() -contains $aliceName) {
        $aliceExisted = $true
        $aliceValue = $key.GetValue($aliceName)
        $aliceKind = $key.GetValueKind($aliceName).ToString()
    }
}
$manifest = [pscustomobject]@{
    Version = 1
    CreatedAt = (Get-Date).ToString('o')
    BackupDirectory = $backupDir
    AllowedDomains = $allowed
    Entries = $entries
    YandexAlice = [pscustomobject]@{
        Existed = $aliceExisted
        Value = $aliceValue
        Kind = $aliceKind
    }
}
# Save a recovery manifest BEFORE making any changes.
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ManifestPath -Encoding UTF8

try {
    foreach ($root in $browserRoots) {
        # Create parent keys safely even if this browser has never been installed.
        $relativeRoot = $root.Substring(5)
        $created = [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($relativeRoot)
        if (-not $created) { throw "Cannot create registry key: $root" }
        $created.Close()
        foreach ($name in $names) {
            $path = ("$root\$name") -replace '^HKLM\\', 'Registry::HKEY_LOCAL_MACHINE\'
            if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Recurse -Force }
            New-Item -Path $path -Force | Out-Null
            if ($name -eq 'URLBlocklist') {
                New-ItemProperty -LiteralPath $path -Name '1' -Value '*' -PropertyType String -Force | Out-Null
            } elseif ($name -eq 'URLAllowlist') {
                $i = 0
                foreach ($domain in $allowed) {
                    $i++
                    New-ItemProperty -LiteralPath $path -Name ([string]$i) -Value $domain -PropertyType String -Force | Out-Null
                }
            } elseif ($name -eq 'ExtensionInstallBlocklist') {
                New-ItemProperty -LiteralPath $path -Name '1' -Value '*' -PropertyType String -Force | Out-Null
            }
        }
    }
    New-Item -Path $yandexRoot -Force | Out-Null
    New-ItemProperty -LiteralPath $yandexRoot -Name $aliceName -Value 1 -PropertyType DWord -Force | Out-Null
    Write-Host ''
    Write-Host 'ROLAB Exam Lock policies installed.' -ForegroundColor Green
    Write-Host ('Allowed domain(s): ' + ($allowed -join ', '))
    Write-Host 'Google Chrome: URL + extension rules'
    Write-Host 'Microsoft Edge: URL + extension rules'
    Write-Host 'Yandex Browser: URL + extension rules + Alice AI off (supported versions)'
    Write-Host ('Recovery backup: ' + $backupDir)
    Write-Host 'Fully CLOSE and re-open browsers, then verify the policy pages.'
    Write-Host 'NOTE: This does NOT lock down Windows. Use an Edge assigned-access kiosk for a stronger exam mode.' -ForegroundColor Yellow
} catch {
    Write-Host ('Installation error: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'A backup manifest exists. Run RESTORE_PREVIOUS_SETTINGS.bat as administrator.' -ForegroundColor Yellow
    throw
}

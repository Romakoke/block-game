@echo off
cd /d "%~dp0"
echo ROLAB EXAM LOCK - pilot installation
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1"
echo.
pause

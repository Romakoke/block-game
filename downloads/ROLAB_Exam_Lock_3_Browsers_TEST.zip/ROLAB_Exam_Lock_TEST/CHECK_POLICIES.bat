@echo off
cd /d "%~dp0"
echo ROLAB EXAM LOCK - status
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\check.ps1"
echo.
pause

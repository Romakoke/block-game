@echo off
cd /d "%~dp0"
echo ROLAB EXAM LOCK - restore settings
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\restore.ps1"
echo.
pause
